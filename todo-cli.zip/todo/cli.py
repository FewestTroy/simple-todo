import argparse
from .models import Task
from .storage import load_tasks, save_tasks, next_id, DEFAULT_PATH

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="todo", description="Simple CLI todo app")
    p.add_argument("--db", default=DEFAULT_PATH, help=f"Path to storage file (default: {DEFAULT_PATH})")

    sub = p.add_subparsers(dest="cmd", required=True)

    add = sub.add_parser("add", help="Add a new task")
    add.add_argument("title", nargs="+", help="Task title")

    ls = sub.add_parser("list", help="List tasks")
    ls.add_argument("-a", "--all", action="store_true", help="Include completed tasks")

    done = sub.add_parser("done", help="Mark task as done")
    done.add_argument("id", type=int, help="Task id")

    rm = sub.add_parser("rm", help="Remove a task")
    rm.add_argument("id", type=int, help="Task id")

    return p

def handle_command(args):
    tasks = load_tasks(args.db)

    if args.cmd == "add":
        title = " ".join(args.title)
        t = Task(id=next_id(tasks), title=title)
        tasks.append(t)
        save_tasks(tasks, args.db)
        print(f"Added task #{t.id}: {t.title}")

    elif args.cmd == "list":
        for t in (tasks if args.all else [t for t in tasks if not t.done]):
            status = "✓" if t.done else " "
            print(f"[{status}] #{t.id} {t.title} (created {t.created_at})")

    elif args.cmd == "done":
        for t in tasks:
            if t.id == args.id:
                t.done = True
                save_tasks(tasks, args.db)
                print(f"Marked task #{t.id} as done")
                return
        print(f"Task #{args.id} not found")

    elif args.cmd == "rm":
        new_tasks = [t for t in tasks if t.id != args.id]
        if len(new_tasks) != len(tasks):
            save_tasks(new_tasks, args.db)
            print(f"Removed task #{args.id}")
        else:
            print(f"Task #{args.id} not found")
