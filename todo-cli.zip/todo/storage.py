import json
import os
from typing import List
from .models import Task

DEFAULT_PATH = os.path.join(os.path.expanduser("~"), ".todo_cli.json")

def _ensure_file(path: str = DEFAULT_PATH):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"tasks": []}, f)

def load_tasks(path: str = DEFAULT_PATH) -> List[Task]:
    _ensure_file(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [Task.from_dict(t) for t in data.get("tasks", [])]

def save_tasks(tasks: List[Task], path: str = DEFAULT_PATH):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"tasks": [t.to_dict() for t in tasks]}, f, ensure_ascii=False, indent=2)

def next_id(tasks: List[Task]) -> int:
    return (max((t.id for t in tasks), default=0) + 1)
