from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class Task:
    id: int
    title: str
    done: bool = False
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds"))

    def to_dict(self):
        return {"id": self.id, "title": self.title, "done": self.done, "created_at": self.created_at}

    @staticmethod
    def from_dict(d):
        return Task(
            id=d["id"],
            title=d["title"],
            done=d.get("done", False),
            created_at=d.get("created_at"),
        )
