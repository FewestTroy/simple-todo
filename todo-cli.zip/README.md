# Todo CLI

Простой менеджер задач в консоли на Python.

## Установка
```bash
git clone https://github.com/YOUR_USERNAME/todo-cli.git
cd todo-cli
```

## Использование
```bash
python3 main.py add "Купить хлеб"
python3 main.py list
python3 main.py done 1
python3 main.py rm 1
```

Задачи сохраняются в `~/.todo_cli.json`.
